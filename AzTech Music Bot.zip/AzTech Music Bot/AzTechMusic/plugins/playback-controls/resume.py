# ==============================================================================
# resume.py - Resume Playback Command
# ==============================================================================
# This plugin handles resuming paused voice chat playback.
#
# Commands:
# - /resume - Resume paused playback
#
# Requirements:
# - User must be admin or authorized user
# - Music must be currently paused
# ==============================================================================

from pyrogram import filters, types

from AzTechMusic import tune, app, db, lang
from AzTechMusic.helpers import buttons, can_manage_vc


@app.on_message(filters.command(["resume"]) & filters.group & ~app.bl_users)
@lang.language()
@can_manage_vc
async def _resume(_, m: types.Message):
    if not await db.get_call(m.chat.id):
        return await m.reply_text(m.lang["not_playing"])

    if await db.playing(m.chat.id):
        return await m.reply_text(m.lang["play_not_paused"])

    await tune.resume(m.chat.id)
    await m.reply_text(
        text=m.lang["play_resumed"].format(m.from_user.mention),
        reply_markup=buttons.controls(m.chat.id),
    )
