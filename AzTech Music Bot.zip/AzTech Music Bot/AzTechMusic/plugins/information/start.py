# ==============================================================================
# start.py - Start Command and Basic Bot Interactions
# ==============================================================================
# This plugin handles:
# - /start command (welcome message for new users)
# - /help command (show help menu)
# - /playmode or /settings command (group settings)
# - New member detection (when bot joins a group)
# ==============================================================================

from pyrogram import enums, errors, filters, types

from AzTechMusic import app, config, db, lang
from AzTechMusic.helpers import buttons, utils


async def _get_force_join_link() -> str | None:
    """Return a join link/username link for the force join channel, if possible."""
    try:
        chat = await app.get_chat(config.FORCE_JOIN_CHANNEL)
        if getattr(chat, "username", None):
            return f"https://t.me/{chat.username}"
        # Fallback: try exporting invite link (requires admin rights)
        try:
            return await app.export_chat_invite_link(config.FORCE_JOIN_CHANNEL)
        except Exception:
            return None
    except Exception:
        return None


async def _is_force_joined(user_id: int) -> bool:
    """Check if the user has joined the configured force join channel."""
    try:
        member = await app.get_chat_member(config.FORCE_JOIN_CHANNEL, user_id)
        # statuses: owner/administrator/member/restricted/left/kicked
        return member.status not in (enums.ChatMemberStatus.LEFT, enums.ChatMemberStatus.BANNED)
    except Exception:
        return False


def _force_join_markup(join_link: str | None) -> types.InlineKeyboardMarkup:
    rows = []
    if join_link:
        rows.append([types.InlineKeyboardButton(text="ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ", url=join_link)])
    rows.append([types.InlineKeyboardButton(text="✅ ᴠᴇʀɪғʏ", callback_data="fsub_verify")])
    return types.InlineKeyboardMarkup(rows)


async def _send_force_join(message: types.Message):
    join_link = await _get_force_join_link()
    text = (
        "╭━━━━━━━━━━━━━━━━━╮\n"
        "┃  <b>🔐 ᴀᴄᴄᴇꜱꜱ ʀᴇꜱᴛʀɪᴄᴛᴇᴅ</b>  ┃\n"
        "╰━━━━━━━━━━━━━━━━━╯\n\n"
        "👋 <b>ʜᴇʟʟᴏ!</b> {}\n\n"
        "📢 <b>ᴛᴏ ᴜꜱᴇ ᴛʜɪꜱ ʙᴏᴛ, ʏᴏᴜ ᴍᴜꜱᴛ ᴊᴏɪɴ ᴏᴜʀ ᴏꜰꜰɪᴄɪᴀʟ ᴄʜᴀɴɴᴇʟ</b>\n\n"
        "━━━━━━━━━━━━━━━━━\n"
        "📌 <b>ꜰᴏʟʟᴏᴡ ᴛʜᴇꜱᴇ ꜱᴛᴇᴘꜱ:</b>\n\n"
        "  <b>1️⃣</b> ᴄʟɪᴄᴋ ᴏɴ <b>\"ᴊᴏɪɴ ᴄʜᴀɴɴᴇʟ\"</b> ʙᴜᴛᴛᴏɴ\n"
        "  <b>2️⃣</b> ᴊᴏɪɴ ᴛʜᴇ ᴄʜᴀɴɴᴇʟ\n"
        "  <b>3️⃣</b> ᴄᴏᴍᴇ ʙᴀᴄᴋ ᴀɴᴅ ᴄʟɪᴄᴋ <b>\"✅ ᴠᴇʀɪꜰʏ\"</b>\n\n"
        "━━━━━━━━━━━━━━━━━\n\n"
        "💡 <i>ᴀꜰᴛᴇʀ ᴊᴏɪɴɪɴɢ, ʏᴏᴜ'ʟʟ ɢᴇᴛ ꜰᴜʟʟ ᴀᴄᴄᴇꜱꜱ!</i>\n\n"
        "🎵 <b>ᴘᴏᴡᴇʀᴇᴅ ʙʏ</b> <b><i><a href='https://t.me/aztechdeveloper'>ᴀᴢᴛᴇᴄʜ</a></i></b>"
    ).format(message.from_user.first_name or "User")
    try:
        await message.reply_photo(
            photo=config.START_IMG,
            caption=text,
            reply_markup=_force_join_markup(join_link),
            quote=True,
        )
    except errors.ChatSendPhotosForbidden:
        await message.reply_text(
            text=text,
            reply_markup=_force_join_markup(join_link),
            quote=True,
        )


@app.on_message(filters.command(["help"]) & filters.private & ~app.bl_users)
@lang.language()
async def _help(_, m: types.Message):
    """Handle /help command in private chats - shows help menu."""
    await m.reply_text(
        text=m.lang["help_menu"],
        reply_markup=buttons.help_markup(m.lang),
        quote=True,
    )


@app.on_message(filters.command(["start"]))
@lang.language()
async def start(_, message: types.Message):
    """
    Handle /start command - welcome message for users.

    - In private chat: Shows welcome message with inline buttons
    - In group chat: Shows short welcome message
    - Adds new users to database
    - Sends log to logger group for new users
    """
    # Skip if message from channel or anonymous admin
    if not message.from_user:
        return

    # Check if user is blacklisted
    if message.from_user.id in app.bl_users and message.from_user.id not in db.notified:
        return await message.reply_text(message.lang["bl_user_notify"])

    # If /start help, show help menu
    if len(message.command) > 1 and message.command[1] == "help":
        return await _help(_, message)

    # Determine if chat is private or group
    private = message.chat.type == enums.ChatType.PRIVATE

    # FORCE JOIN CHECK - Private chats only
    if private and config.FORCE_JOIN_CHANNEL:
        is_joined = await _is_force_joined(message.from_user.id)
        if not is_joined:
            return await _send_force_join(message)

    # Choose appropriate welcome message
    _text = (
        message.lang["start_pm"].format(message.from_user.first_name, app.name)
        if private
        else message.lang["start_gp"].format(app.name)
    )

    key = buttons.start_key(message.lang, private)
    try:
        await message.reply_photo(
            photo=config.START_IMG,
            caption=_text,
            reply_markup=key,
            quote=not private,
        )
    except errors.ChatSendPhotosForbidden:
        # If photos are not allowed, send text only
        await message.reply_text(
            text=_text,
            reply_markup=key,
            quote=not private,
        )

    # For private chats, add user to database if new
    if private:
        if await db.is_user(message.from_user.id):
            return  # User already exists, no need to add
        # Log new user to logger group
        await utils.send_log(message)
        # Add user to database
        return await db.add_user(message.from_user.id)


@app.on_message(filters.command(["playmode", "settings"]) & filters.group & ~app.bl_users)
@lang.language()
async def settings(_, message: types.Message):
    """
    Handle /playmode or /settings command - show group settings.

    Displays:
    - Play mode (everyone or admin only)
    - Current language
    - Options to change settings
    """
    admin_only = await db.get_play_mode(message.chat.id)  # Get play mode setting
    await message.reply_text(
        text=message.lang["start_settings"].format(message.chat.title),
        reply_markup=buttons.settings_markup(message.lang, admin_only, message.chat.id),
        quote=True,
    )


@app.on_callback_query(filters.regex(r"^fsub_verify$") & ~app.bl_users)
@lang.language()
async def _force_join_verify(_, query: types.CallbackQuery):
    """Handle force join verification callback."""
    user_id = query.from_user.id
    
    # Check if user has joined
    is_joined = await _is_force_joined(user_id)
    
    if not is_joined:
        await query.answer(
            "❌ You haven't joined the channel yet!\n\nPlease join first, then click Verify.",
            show_alert=True
        )
        return
    
    # User has joined - show normal start message
    await query.answer("✅ Verified! Welcome to the bot!", show_alert=True)
    
    _text = query.lang["start_pm"].format(query.from_user.first_name, app.name)
    key = buttons.start_key(query.lang, private=True)
    
    try:
        await query.message.edit_media(
            media=types.InputMediaPhoto(media=config.START_IMG, caption=_text),
            reply_markup=key,
        )
    except Exception:
        # Fallback: edit text only if media edit fails
        try:
            await query.message.edit_text(text=_text, reply_markup=key)
        except Exception:
            pass
    
    # Add user to database if new
    if not await db.is_user(user_id):
        # Create a pseudo-message object for logging with lang attribute
        # Since query.message doesn't have lang, we create a simple log
        try:
            await app.send_message(
                config.LOGGER_ID,
                f"#NEW_USER\n\n"
                f"**ID:** `{user_id}`\n"
                f"**Name:** {query.from_user.mention}\n"
                f"**Username:** @{query.from_user.username or 'None'}"
            )
        except Exception:
            pass
        await db.add_user(user_id)


@app.on_message(filters.new_chat_members, group=7)
@lang.language()
async def _new_member(_, message: types.Message):
    """
    Handle new member events - detect when bot is added to groups.

    - Leaves non-supergroup chats
    - Adds new groups to database
    """
    # Only work in supergroups (not basic groups)
    if message.chat.type != enums.ChatType.SUPERGROUP:
        return await message.chat.leave()

    # Check each new member
    for member in message.new_chat_members:
        if member.id == app.id:  # Bot itself was added
            if await db.is_chat(message.chat.id):
                return  # Chat already in database
            # Add chat to database (log is sent from new_chat.py with photo)
            await db.add_chat(message.chat.id)
