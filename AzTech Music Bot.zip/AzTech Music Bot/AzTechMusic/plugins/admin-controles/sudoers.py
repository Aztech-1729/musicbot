# ==============================================================================
# sudoers.py - Sudo User Management (Owner Only)
# ==============================================================================
# This plugin allows the bot owner to add/remove sudo users.
# Sudo users have elevated permissions and can use admin commands.
#
# Commands:
# - /addsudo <user> - Grant sudo permissions
# - /delsudo <user> - Revoke sudo permissions
# - /rmsudo <user> - Same as /delsudo
#
# Only the bot owner (defined in config) can manage sudo users.
# ==============================================================================

from pyrogram import filters, types

from AzTechMusic import app, db, lang
from AzTechMusic.helpers import utils


@app.on_message(filters.command(["addsudo", "delsudo", "rmsudo"]) & app.sudo_filter)
@lang.language()
async def _sudo(_, m: types.Message):
    user = await utils.extract_user(m)
    if not user:
        return await m.reply_text(m.lang["user_not_found"])

    if m.command[0] == "addsudo":
        if user.id in app.sudoers:
            return await m.reply_text(m.lang["sudo_already"].format(user.mention))

        app.sudoers.add(user.id)
        app.sudo_filter.update([user.id])
        await db.add_sudo(user.id)
        await m.reply_text(m.lang["sudo_added"].format(user.mention))
    else:
        if user.id not in app.sudoers:
            return await m.reply_text(m.lang["sudo_not"].format(user.mention))

        app.sudoers.discard(user.id)
        app.sudo_filter.update([])  # Reset filter
        app.sudo_filter.update(app.sudoers)  # Rebuild with remaining users
        await db.del_sudo(user.id)
        await m.reply_text(m.lang["sudo_removed"].format(user.mention))


o_mention = None


@app.on_message(filters.command(["listsudo", "sudolist"]))
@lang.language()
async def _listsudo(_, m: types.Message):
    global o_mention
    sent = await m.reply_text(m.lang["sudo_fetching"])

    if not o_mention:
        o_mention = (await app.get_users(app.owner)).mention
    txt = m.lang["sudo_owner"].format(o_mention)
    sudoers = await db.get_sudoers()
    if sudoers:
        txt += m.lang["sudo_users"]

    for user_id in sudoers:
        try:
            user = (await app.get_users(user_id)).mention
            txt += f"\n- {user}"
        except:
            continue

    await sent.edit_text(txt)
