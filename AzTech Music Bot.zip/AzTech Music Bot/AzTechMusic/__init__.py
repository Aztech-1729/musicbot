"""
AzTechMusicBot - Advanced Telegram Music Bot

This is the main initialization module that sets up logging, configuration,
and all core components required for the bot to function.
"""

import asyncio
import time
import logging
from logging.handlers import RotatingFileHandler
from typing import List

# Configure logging
logging.basicConfig(
    format="[%(asctime)s - %(levelname)s] - %(name)s: %(message)s",
    datefmt="%d-%b-%y %H:%M:%S",
    handlers=[
        RotatingFileHandler("log.txt", maxBytes=10485760, backupCount=5, encoding="utf-8"),
        logging.StreamHandler(),
    ],
    level=logging.INFO,
)

# Reduce noise from third-party libraries
logging.getLogger("httpx").setLevel(logging.ERROR)
logging.getLogger("ntgcalls").setLevel(logging.CRITICAL)
logging.getLogger("pymongo").setLevel(logging.ERROR)
logging.getLogger("pyrogram").setLevel(logging.ERROR)
logging.getLogger("pytgcalls").setLevel(logging.ERROR)

logger = logging.getLogger("AzTechMusic")

# Version
__version__ = "3.0.1"

# Load configuration
from config import Config

config = Config()
config.check()

# Global task list for background tasks
tasks: List = []
boot: float = time.time()

# Initialize bot client
from AzTechMusic.core.bot import Bot
app = Bot()

# Ensure required directories exist
from AzTechMusic.core.dir import ensure_dirs
ensure_dirs()

# Initialize userbot/assistant clients
from AzTechMusic.core.userbot import Userbot
userbot = Userbot()

# Initialize database connection
from AzTechMusic.core.mongo import MongoDB
db = MongoDB()

# Initialize language system
from AzTechMusic.core.lang import Language
lang = Language()

# Initialize Telegram and YouTube utilities
from AzTechMusic.core.telegram import Telegram
from AzTechMusic.core.youtube import YouTube
tg = Telegram()
yt = YouTube()

# Initialize preload manager for background track downloading
from AzTechMusic.core.preload import PreloadManager
preload = PreloadManager()

# Initialize queue manager
from AzTechMusic.helpers import Queue
queue = Queue()

# Initialize call handler
from AzTechMusic.core.calls import TgCall
tune = TgCall()


async def stop() -> None:
    """
    Gracefully shutdown the bot and all its components.
    
    This function:
    - Cancels all running background tasks
    - Closes bot and userbot connections
    - Closes database connection
    - Logs shutdown completion
    """
    logger.info("Stopping bot...")
    
    # Stop tournament timer monitor (disabled - not implemented)
    # try:
    #     from AzTechMusic.helpers._tournament import stop_timer_monitor
    #     stop_timer_monitor()
    # except Exception as e:
    #     logger.error(f"Error stopping tournament timer: {e}")
    
    # Cancel all background tasks
    for task in tasks:
        task.cancel()
        try:
            await task
        except asyncio.CancelledError:
            # Expected when cancelling tasks - suppress the error
            pass
        except Exception:
            pass
    
    # Close all connections
    await app.exit()
    await userbot.exit()
    await db.close()
    
    logger.info("Bot stopped successfully.\n")
