#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
YouTube Cookie Generator for AzTech Music Bot
Automatically logs into YouTube and saves cookies for bot to use
Run this on your VPS/local machine to generate fresh cookies
"""

import os
import sys
import json
import time
from pathlib import Path
from typing import Optional

try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
except ImportError:
    print("❌ Selenium not installed!")
    print("Install with: pip install selenium")
    sys.exit(1)

try:
    import yt_dlp
except ImportError:
    print("❌ yt-dlp not installed!")
    print("Install with: pip install yt-dlp")
    sys.exit(1)


class YouTubeCookieGenerator:
    def __init__(self, headless: bool = False):
        """Initialize Chrome browser with proper options"""
        self.headless = headless
        self.driver = None
        self.cookies_dir = Path("AzTechMusic/cookies")
        
        # Create cookies directory if it doesn't exist
        self.cookies_dir.mkdir(parents=True, exist_ok=True)
        
    def setup_browser(self):
        """Setup Chrome browser with necessary options"""
        print("🔧 Setting up Chrome browser...")
        
        chrome_options = Options()
        
        if self.headless:
            chrome_options.add_argument("--headless=new")
        
        # Critical options for VPS/Linux environment
        chrome_options.add_argument("--no-sandbox")
        chrome_options.add_argument("--disable-dev-shm-usage")
        chrome_options.add_argument("--disable-gpu")
        chrome_options.add_argument("--disable-web-resources")
        chrome_options.add_argument("--disable-extensions")
        chrome_options.add_argument("--disable-plugins")
        
        # Security and automation detection bypass
        chrome_options.add_argument("--disable-blink-features=AutomationControlled")
        chrome_options.add_experimental_option("excludeSwitches", ["enable-automation"])
        chrome_options.add_experimental_option('useAutomationExtension', False)
        
        # User agent
        chrome_options.add_argument("user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
        
        # Create driver
        try:
            # Try to use chromedriver from PATH
            self.driver = webdriver.Chrome(options=chrome_options)
            print("✓ Chrome browser initialized")
            return True
        except Exception as e:
            print(f"❌ Failed to initialize Chrome: {e}")
            print("\n🔧 VPS Setup Instructions:")
            print("\n1. Install Chromium:")
            print("   Ubuntu/Debian:")
            print("   sudo apt-get update")
            print("   sudo apt-get install -y chromium-browser chromium-chromedriver")
            print("\n2. For headless mode, install Xvfb:")
            print("   sudo apt-get install -y xvfb")
            print("\n3. Run with Xvfb:")
            print("   xvfb-run -a python generate_cookies.py")
            print("\n4. Or set DISPLAY variable:")
            print("   export DISPLAY=:99")
            print("   python generate_cookies.py")
            return False
    
    def login_to_youtube(self, email: str, password: str) -> bool:
        """Login to YouTube using provided credentials"""
        try:
            print("\n🔐 Logging into YouTube...")
            
            # Navigate to YouTube
            self.driver.get("https://www.youtube.com")
            print("✓ Navigated to YouTube")
            
            # Wait for sign-in button and click
            time.sleep(3)
            
            # Find and click sign in button
            sign_in_buttons = self.driver.find_elements(By.XPATH, 
                "//a[contains(@href, 'accounts.google.com') or contains(text(), 'Sign in')]")
            
            if sign_in_buttons:
                sign_in_buttons[0].click()
                print("✓ Clicked sign in button")
            else:
                print("⚠️ Could not find sign in button, trying direct navigation...")
                self.driver.get("https://accounts.google.com/ServiceLogin?service=youtube")
            
            # Wait for email input
            print("⏳ Waiting for email input...")
            email_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.ID, "identifierId"))
            )
            print("✓ Email field found")
            
            # Enter email
            email_field.send_keys(email)
            self.driver.find_element(By.ID, "identifierNext").click()
            print("✓ Email entered")
            
            # Wait for password input
            print("⏳ Waiting for password input...")
            password_field = WebDriverWait(self.driver, 10).until(
                EC.presence_of_element_located((By.NAME, "password"))
            )
            print("✓ Password field found")
            
            # Enter password
            password_field.send_keys(password)
            self.driver.find_element(By.ID, "passwordNext").click()
            print("✓ Password entered")
            
            # Wait for YouTube to load after login
            print("⏳ Waiting for YouTube to load after login...")
            time.sleep(5)
            
            # Check if login was successful
            current_url = self.driver.current_url
            if "youtube.com" in current_url:
                print("✓ Successfully logged into YouTube!")
                return True
            else:
                print(f"❌ Login may have failed. Current URL: {current_url}")
                return False
                
        except Exception as e:
            print(f"❌ Login error: {e}")
            return False
    
    def extract_cookies(self) -> dict:
        """Extract cookies from browser"""
        try:
            print("\n🍪 Extracting cookies...")
            cookies = self.driver.get_cookies()
            
            # Convert to dictionary
            cookies_dict = {}
            for cookie in cookies:
                cookies_dict[cookie['name']] = cookie['value']
            
            print(f"✓ Extracted {len(cookies)} cookies")
            return cookies_dict
        except Exception as e:
            print(f"❌ Error extracting cookies: {e}")
            return {}
    
    def save_cookies_netscape_format(self, cookies: dict, filename: str = "cookies.txt") -> bool:
        """Save cookies in Netscape format for yt-dlp"""
        try:
            print(f"\n💾 Saving cookies in Netscape format...")
            
            cookie_file = self.cookies_dir / filename
            
            with open(cookie_file, 'w') as f:
                # Write header
                f.write("# Netscape HTTP Cookie File\n")
                f.write("# This file is generated by AzTech Music Bot Cookie Generator\n")
                f.write("# Do not edit manually\n\n")
                
                # Write cookies
                for name, value in cookies.items():
                    # Format: domain flag path secure expiration name value
                    line = f".youtube.com\tTRUE\t/\tTRUE\t0\t{name}\t{value}\n"
                    f.write(line)
            
            file_size = cookie_file.stat().st_size
            print(f"✓ Cookies saved to: {cookie_file}")
            print(f"  File size: {file_size} bytes")
            return True
            
        except Exception as e:
            print(f"❌ Error saving cookies: {e}")
            return False
    
    def verify_cookies(self, filename: str = "cookies.txt") -> bool:
        """Verify cookies work with yt-dlp"""
        try:
            print(f"\n✅ Verifying cookies...")
            
            cookie_file = self.cookies_dir / filename
            
            # Test with yt-dlp
            ydl_opts = {
                'quiet': True,
                'no_warnings': True,
                'cookiefile': str(cookie_file),
                'socket_timeout': 30,
            }
            
            with yt_dlp.YoutubeDL(ydl_opts) as ydl:
                # Try to fetch info from a test video
                print("⏳ Testing cookies with yt-dlp...")
                try:
                    info = ydl.extract_info("https://www.youtube.com/watch?v=jNQXAC9IVRw", download=False)
                    print("✓ Cookies verified successfully!")
                    print(f"  Video: {info.get('title')}")
                    return True
                except Exception as e:
                    if "Sign in" in str(e) or "bot" in str(e).lower():
                        print("⚠️ Cookies may not be working yet (YouTube bot detection)")
                        print("   Try again in a few moments or use different account")
                    else:
                        print(f"⚠️ Verification warning: {str(e)[:100]}")
                    return False
                    
        except Exception as e:
            print(f"❌ Verification error: {e}")
            return False
    
    def cleanup(self):
        """Close browser and cleanup"""
        if self.driver:
            self.driver.quit()
            print("\n✓ Browser closed")
    
    def run(self, email: str, password: str, headless: bool = False) -> bool:
        """Main execution flow"""
        try:
            self.headless = headless
            
            print("\n" + "="*80)
            print("🎵 AzTech Music Bot - YouTube Cookie Generator")
            print("="*80)
            
            # Setup browser
            if not self.setup_browser():
                return False
            
            # Login to YouTube
            if not self.login_to_youtube(email, password):
                self.cleanup()
                return False
            
            # Extract cookies
            cookies = self.extract_cookies()
            if not cookies:
                self.cleanup()
                return False
            
            # Save cookies
            if not self.save_cookies_netscape_format(cookies):
                self.cleanup()
                return False
            
            # Verify cookies
            self.verify_cookies()
            
            # Cleanup
            self.cleanup()
            
            print("\n" + "="*80)
            print("✅ Cookie generation complete!")
            print("="*80)
            print("\n📝 Next steps:")
            print("  1. Restart your AzTech Music Bot")
            print("  2. Bot will automatically use the cookies")
            print("  3. YouTube downloads should now work!")
            print("\n💡 Tip: Regenerate cookies if downloads stop working")
            print("="*80 + "\n")
            
            return True
            
        except Exception as e:
            print(f"\n❌ Unexpected error: {e}")
            self.cleanup()
            return False


def main():
    """Main entry point"""
    print("\n" + "="*80)
    print("🔑 YouTube Cookie Generator for AzTech Music Bot")
    print("="*80)
    print("\nThis script will:")
    print("  1. Open Chrome browser")
    print("  2. Login to your YouTube account")
    print("  3. Extract authentication cookies")
    print("  4. Save cookies for bot to use")
    print("  5. Verify cookies work with yt-dlp")
    print("\n⚠️  Important:")
    print("  • Use a dedicated account (not personal)")
    print("  • Keep this account logged in on YouTube")
    print("  • Cookies expire after ~1 month (regenerate as needed)")
    print("="*80 + "\n")
    
    # Get credentials
    email = input("📧 Enter YouTube email: ").strip()
    if not email:
        print("❌ Email cannot be empty")
        return False
    
    password = input("🔐 Enter YouTube password: ").strip()
    if not password:
        print("❌ Password cannot be empty")
        return False
    
    # Ask about headless mode
    headless_input = input("\n🖥️  Run in headless mode? (y/n) [default: n]: ").strip().lower()
    headless = headless_input == 'y'
    
    if headless:
        print("⚠️  Running in headless mode - monitor the process")
    else:
        print("💡 Browser window will open - don't close it")
    
    # Run generator
    generator = YouTubeCookieGenerator()
    success = generator.run(email, password, headless)
    
    return success


if __name__ == "__main__":
    try:
        success = main()
        sys.exit(0 if success else 1)
    except KeyboardInterrupt:
        print("\n\n❌ Process cancelled by user")
        sys.exit(1)
