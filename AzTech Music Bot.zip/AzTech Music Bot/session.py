﻿"""
Generate STRING_SESSION for AzTechMusicBot

Interactive login:
1. Run this file: python session.py
2. Enter your phone number
3. Enter OTP code
4. 2FA password (if enabled)
5. Session string will be saved and printed
6. Copy to .env file: STRING_SESSION=<output>
"""

import asyncio
import sys
from pyrogram import Client
from dotenv import load_dotenv
from os import getenv

# Ensure UTF-8 output on Windows terminals
try:
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    if hasattr(sys.stderr, "reconfigure"):
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
except Exception:
    pass

# Load API credentials from .env
load_dotenv()
API_ID = int(getenv("API_ID", "0"))
API_HASH = getenv("API_HASH", "")

if not API_ID or not API_HASH:
    raise SystemExit("Missing API_ID/API_HASH in .env. Please set them and re-run session.py")


async def generate_session():
    """Generate session string by logging in interactively"""
    
    app = Client(
        name="AzTechTuneUB1",
        api_id=API_ID,
        api_hash=API_HASH,
    )
    
    try:
        print("Starting interactive login...\n")
        await app.start()
        
        # Get session string
        session_string = await app.export_session_string()
        
        print("\nSession generated successfully.\n")
        print("=" * 80)
        print("STRING_SESSION:")
        print(session_string)
        print("=" * 80)
        print("\nCopy the above STRING_SESSION and add to .env file:")
        print('STRING_SESSION=<paste_above_string>\n')
        
        await app.stop()
        
        return session_string
        
    except Exception as e:
        print(f"âŒ Error: {e}")
        return None


if __name__ == "__main__":
    print("AzTechMusicBot - Session Generator\n")
    asyncio.run(generate_session())

